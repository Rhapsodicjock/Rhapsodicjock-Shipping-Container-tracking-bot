from abc import ABC, abstractmethod
from typing import Dict, Any
from ..models import TrackingResult

class BaseCarrier(ABC):
    name: str

    def __init__(self, context, timeout_ms: int = 90000):
        self.context = context
        self.timeout_ms = timeout_ms

    @abstractmethod
    async def track(self, container_no: str) -> Dict[str, Any]:
        """Return a raw dict with keys: status, last_location, eta, success, error"""
        ...
